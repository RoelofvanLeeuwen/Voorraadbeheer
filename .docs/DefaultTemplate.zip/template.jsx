/* global React */

// ============================================================
// Graafschap College — Blazor Template
// A drop-in design system for replacing the default Blazor shell
// ============================================================

const NAV_ITEMS = [
  { id: 'home', label: 'Home', icon: 'home' },
  { id: 'counter', label: 'Counter', icon: 'counter' },
  { id: 'weather', label: 'Weather', icon: 'cloud' },
  { id: 'data', label: 'Data', icon: 'table' },
  { id: 'about', label: 'Over', icon: 'info' },
];

function Icon({ name, size = 20, stroke = 1.8 }) {
  const props = {
    width: size, height: size, viewBox: '0 0 24 24',
    fill: 'none', stroke: 'currentColor', strokeWidth: stroke,
    strokeLinecap: 'round', strokeLinejoin: 'round',
  };
  switch (name) {
    case 'home': return <svg {...props}><path d="M3 11.5 12 4l9 7.5"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/></svg>;
    case 'counter': return <svg {...props}><rect x="4" y="6" width="16" height="12" rx="2"/><path d="M9 10v4M12 10v4M15 10v4"/></svg>;
    case 'cloud': return <svg {...props}><path d="M7 18a4 4 0 1 1 1-7.87A5 5 0 0 1 18 11a3.5 3.5 0 0 1 0 7Z"/></svg>;
    case 'table': return <svg {...props}><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M9 4v16"/></svg>;
    case 'info': return <svg {...props}><circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/></svg>;
    case 'menu': return <svg {...props}><path d="M4 7h16M4 12h16M4 17h16"/></svg>;
    case 'close': return <svg {...props}><path d="M6 6l12 12M18 6 6 18"/></svg>;
    case 'search': return <svg {...props}><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>;
    case 'bell': return <svg {...props}><path d="M6 8a6 6 0 1 1 12 0c0 4 2 5 2 7H4c0-2 2-3 2-7Z"/><path d="M10 19a2 2 0 1 0 4 0"/></svg>;
    case 'sun': return <svg {...props}><circle cx="12" cy="12" r="4"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6l1.4 1.4M17 17l1.4 1.4M5.6 18.4 7 17M17 7l1.4-1.4"/></svg>;
    case 'plus': return <svg {...props}><path d="M12 5v14M5 12h14"/></svg>;
    case 'minus': return <svg {...props}><path d="M5 12h14"/></svg>;
    case 'chevron': return <svg {...props}><path d="m6 9 6 6 6-6"/></svg>;
    case 'check': return <svg {...props}><path d="m5 12 5 5 9-11"/></svg>;
    case 'arrow': return <svg {...props}><path d="M5 12h14M13 6l6 6-6 6"/></svg>;
    case 'sparkle': return <svg {...props}><path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5 18 18M6 18l2.5-2.5M15.5 8.5 18 6"/></svg>;
    default: return null;
  }
}

// ============================================================
// The actual template shell — used inside every artboard
// ============================================================
function BlazorShell({ mode, openMobile, page = 'home', projectTitle = 'Mijn Project', primary = '#E5007D' }) {
  // mode: 'desktop' | 'mobile'
  const isMobile = mode === 'mobile';

  return (
    <div className="gc-shell" style={{ '--gc-primary': primary }}>
      {/* App Bar */}
      <header className="gc-appbar">
        <div className="gc-appbar-inner">
          <div className="gc-brand">
            {isMobile && (
              <button className="gc-iconbtn gc-hamburger" aria-label="Menu">
                <Icon name={openMobile ? 'close' : 'menu'} size={22} />
              </button>
            )}
            <a className="gc-logo" href="#">
              <span className="gc-logo-mark" aria-hidden>
                <svg width="28" height="28" viewBox="0 0 32 32" fill="none">
                  <rect width="32" height="32" rx="8" fill="var(--gc-primary)"/>
                  <path d="M10 9v14M10 9h8a5 5 0 0 1 0 10h-3v4" stroke="white" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </span>
              <span className="gc-logo-text">
                <span className="gc-logo-org">Graafschap</span>
                <span className="gc-logo-sub">{projectTitle}</span>
              </span>
            </a>
          </div>

          {!isMobile && (
            <nav className="gc-nav">
              {NAV_ITEMS.map((item, i) => (
                <a key={item.id} href="#" className={`gc-nav-link ${page === item.id ? 'is-active' : ''}`}>
                  {item.label}
                </a>
              ))}
            </nav>
          )}

          <div className="gc-appbar-actions">
            {!isMobile && (
              <div className="gc-search">
                <Icon name="search" size={16} />
                <span>Zoeken…</span>
                <kbd>⌘K</kbd>
              </div>
            )}
            <button className="gc-iconbtn" aria-label="Notificaties">
              <Icon name="bell" size={18} />
              <span className="gc-dot" />
            </button>
            <button className="gc-iconbtn" aria-label="Thema">
              <Icon name="sun" size={18} />
            </button>
            <div className="gc-avatar" aria-label="Account">MV</div>
          </div>
        </div>
      </header>

      {/* Mobile drawer */}
      {isMobile && openMobile && (
        <>
          <div className="gc-scrim" />
          <aside className="gc-drawer">
            <div className="gc-drawer-head">
              <div className="gc-logo">
                <span className="gc-logo-mark">
                  <svg width="28" height="28" viewBox="0 0 32 32" fill="none">
                    <rect width="32" height="32" rx="8" fill="var(--gc-primary)"/>
                    <path d="M10 9v14M10 9h8a5 5 0 0 1 0 10h-3v4" stroke="white" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </span>
                <span className="gc-logo-text">
                  <span className="gc-logo-org">Graafschap</span>
                  <span className="gc-logo-sub">{projectTitle}</span>
                </span>
              </div>
              <button className="gc-iconbtn" aria-label="Sluiten"><Icon name="close" size={20}/></button>
            </div>
            <nav className="gc-drawer-nav">
              {NAV_ITEMS.map(item => (
                <a key={item.id} href="#" className={`gc-drawer-link ${page === item.id ? 'is-active' : ''}`}>
                  <span className="gc-drawer-ico"><Icon name={item.icon} size={20}/></span>
                  <span>{item.label}</span>
                </a>
              ))}
            </nav>
            <div className="gc-drawer-foot">
              <div className="gc-avatar" style={{width: 36, height: 36}}>MV</div>
              <div>
                <div className="gc-drawer-user">Marit Velthuis</div>
                <div className="gc-drawer-role">Beheerder</div>
              </div>
            </div>
          </aside>
        </>
      )}

      {/* Page content */}
      <main className="gc-main">
        <PageContent page={page} />
      </main>
    </div>
  );
}

// ============================================================
// Page samples
// ============================================================
function PageContent({ page }) {
  if (page === 'home') return <HomePage />;
  if (page === 'counter') return <CounterPage />;
  if (page === 'weather') return <WeatherPage />;
  if (page === 'data') return <DataPage />;
  return <HomePage />;
}

function PageHeader({ eyebrow, title, sub, action }) {
  return (
    <div className="gc-pageheader">
      <div>
        {eyebrow && <div className="gc-eyebrow">{eyebrow}</div>}
        <h1 className="gc-h1">{title}</h1>
        {sub && <p className="gc-sub">{sub}</p>}
      </div>
      {action}
    </div>
  );
}

function HomePage() {
  return (
    <>
      <PageHeader
        eyebrow="Welkom terug"
        title="Hallo Marit 👋"
        sub="Dit is je startpagina. Hieronder een paar snelle ingangen."
        action={<button className="gc-btn gc-btn-primary"><Icon name="plus" size={16}/> Nieuw item</button>}
      />

      <div className="gc-grid gc-grid-3">
        <Stat label="Actieve studenten" value="1.247" delta="+4,2%" trend="up"/>
        <Stat label="Open aanvragen" value="32" delta="−12%" trend="down"/>
        <Stat label="Voltooid deze week" value="86" delta="+8" trend="up"/>
      </div>

      <div className="gc-grid gc-grid-2" style={{marginTop: 24}}>
        <Card title="Snel aan de slag" sub="Veelgebruikte acties">
          <ul className="gc-actionlist">
            <li><span><Icon name="plus" size={16}/></span>Nieuw dossier aanmaken<Icon name="arrow" size={16}/></li>
            <li><span><Icon name="table" size={16}/></span>Resultaten importeren<Icon name="arrow" size={16}/></li>
            <li><span><Icon name="sparkle" size={16}/></span>Rapportage genereren<Icon name="arrow" size={16}/></li>
            <li><span><Icon name="info" size={16}/></span>Handleiding openen<Icon name="arrow" size={16}/></li>
          </ul>
        </Card>
        <Card title="Recente activiteit" sub="Laatste 24 uur">
          <ul className="gc-timeline">
            <li><i className="dot a"/><div><b>Dossier #4821</b> bijgewerkt door J. Berenschot<time>10 min</time></div></li>
            <li><i className="dot b"/><div><b>3 nieuwe inschrijvingen</b> verwerkt<time>1 uur</time></div></li>
            <li><i className="dot c"/><div><b>Rapport Q2</b> klaar voor review<time>3 uur</time></div></li>
            <li><i className="dot a"/><div><b>Wachtwoordbeleid</b> aangescherpt<time>gisteren</time></div></li>
          </ul>
        </Card>
      </div>
    </>
  );
}

function Stat({ label, value, delta, trend }) {
  return (
    <div className="gc-stat">
      <div className="gc-stat-label">{label}</div>
      <div className="gc-stat-value">{value}</div>
      <div className={`gc-stat-delta ${trend}`}>{delta} <span>vs vorige week</span></div>
    </div>
  );
}

function Card({ title, sub, children }) {
  return (
    <div className="gc-card">
      <div className="gc-card-head">
        <div>
          <div className="gc-card-title">{title}</div>
          {sub && <div className="gc-card-sub">{sub}</div>}
        </div>
        <button className="gc-iconbtn"><Icon name="chevron" size={16}/></button>
      </div>
      <div className="gc-card-body">{children}</div>
    </div>
  );
}

function CounterPage() {
  const [count, setCount] = React.useState(7);
  return (
    <>
      <PageHeader eyebrow="Demo" title="Counter" sub="De klassieker uit de Blazor template — opnieuw vormgegeven."/>
      <div className="gc-counter-card">
        <div className="gc-counter-display">{count}</div>
        <div className="gc-counter-controls">
          <button className="gc-btn gc-btn-ghost" onClick={() => setCount(c => c - 1)}><Icon name="minus" size={18}/></button>
          <button className="gc-btn gc-btn-primary gc-btn-lg" onClick={() => setCount(c => c + 1)}>Click me</button>
          <button className="gc-btn gc-btn-ghost" onClick={() => setCount(c => c + 1)}><Icon name="plus" size={18}/></button>
        </div>
        <div className="gc-counter-meta">Huidige waarde wordt bewaard in de component state.</div>
      </div>
    </>
  );
}

const WEATHER = [
  { date: '2026-05-19', tempC: 18, tempF: 64, sum: 'Mild' },
  { date: '2026-05-20', tempC: 21, tempF: 70, sum: 'Bewolkt' },
  { date: '2026-05-21', tempC: 16, tempF: 61, sum: 'Regen' },
  { date: '2026-05-22', tempC: 23, tempF: 73, sum: 'Zonnig' },
  { date: '2026-05-23', tempC: 19, tempF: 66, sum: 'Wisselend' },
];

function WeatherPage() {
  return (
    <>
      <PageHeader
        eyebrow="Demo"
        title="Weersvoorspelling"
        sub="Voorbeeld van een data-tabel met fetched data."
        action={
          <div className="gc-btn-group">
            <button className="gc-btn gc-btn-ghost">Exporteren</button>
            <button className="gc-btn gc-btn-primary"><Icon name="sparkle" size={16}/> Verversen</button>
          </div>
        }
      />
      <div className="gc-card" style={{padding: 0}}>
        <table className="gc-table">
          <thead>
            <tr>
              <th>Datum</th><th>Temp (°C)</th><th>Temp (°F)</th><th>Samenvatting</th><th></th>
            </tr>
          </thead>
          <tbody>
            {WEATHER.map(r => (
              <tr key={r.date}>
                <td><b>{new Date(r.date).toLocaleDateString('nl-NL', {weekday:'short', day:'numeric', month:'short'})}</b></td>
                <td>{r.tempC}°</td>
                <td>{r.tempF}°</td>
                <td><span className={`gc-pill ${r.sum.toLowerCase()}`}>{r.sum}</span></td>
                <td style={{textAlign:'right'}}><button className="gc-iconbtn"><Icon name="chevron" size={16}/></button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

function DataPage() {
  return (
    <>
      <PageHeader
        eyebrow="Demo"
        title="Nieuw dossier"
        sub="Voorbeeld formulier — valideert client-side."
        action={<button className="gc-btn gc-btn-primary"><Icon name="check" size={16}/> Opslaan</button>}
      />
      <div className="gc-grid gc-grid-2">
        <div className="gc-card">
          <div className="gc-card-head"><div className="gc-card-title">Algemeen</div></div>
          <div className="gc-card-body gc-form">
            <Field label="Dossiernaam" value="Inschrijving 2026 — Software Developer" />
            <Field label="Studentnummer" value="00428193" />
            <div className="gc-form-row">
              <Field label="Cohort" value="2026" />
              <Field label="Niveau" value="4" />
            </div>
            <Field label="Notitie" textarea value="Aanmelding via doe-dag, voorkeur voor BOL traject." />
          </div>
        </div>
        <div className="gc-card">
          <div className="gc-card-head"><div className="gc-card-title">Status</div></div>
          <div className="gc-card-body">
            <div className="gc-radiolist">
              <Radio name="status" label="Concept" desc="Nog niet ingediend." />
              <Radio name="status" label="In review" desc="Wordt gecontroleerd door SLB-er." checked />
              <Radio name="status" label="Goedgekeurd" desc="Klaar voor verwerking." />
              <Radio name="status" label="Afgewezen" desc="Met motivatie." />
            </div>
            <div className="gc-alert">
              <Icon name="info" size={18}/>
              <div>Een dossier kan tot 14 dagen na indienen nog worden aangepast.</div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

function Field({ label, value, textarea }) {
  return (
    <label className="gc-field">
      <span>{label}</span>
      {textarea
        ? <textarea defaultValue={value} rows={3}/>
        : <input defaultValue={value}/>}
    </label>
  );
}

function Radio({ name, label, desc, checked }) {
  return (
    <label className={`gc-radio ${checked ? 'is-checked' : ''}`}>
      <span className="gc-radio-dot"><i/></span>
      <span>
        <b>{label}</b>
        <em>{desc}</em>
      </span>
    </label>
  );
}

window.BlazorShell = BlazorShell;
